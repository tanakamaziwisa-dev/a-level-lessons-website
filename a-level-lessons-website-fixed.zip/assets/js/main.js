/*
  Academic Hub A-Level Lessons — Main JS
  - Active nav highlighting
  - Mobile nav toggle
  - Dark mode toggle (stored in localStorage)
  - Fade-in animations
  - Back-to-top button
  - Contact form -> opens WhatsApp message
*/

document.addEventListener("DOMContentLoaded", () => {
  // --- Active navigation highlighting ---
  const currentPath = (window.location.pathname.split("/").pop() || "index.html").toLowerCase();
  document.querySelectorAll(".nav-links a").forEach((link) => {
    const href = (link.getAttribute("href") || "").toLowerCase();
    if (href === currentPath) link.classList.add("active");
  });

  // --- Mobile nav toggle ---
  const toggle = document.querySelector("[data-nav-toggle]");
  const panel = document.querySelector("[data-nav-panel]");
  const closePanel = () => {
    if (!toggle || !panel) return;
    panel.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
  };

  if (toggle && panel) {
    toggle.addEventListener("click", () => {
      const isOpen = panel.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(isOpen));
    });

    // Close after clicking a nav link (mobile)
    panel.querySelectorAll("a").forEach((a) => {
      a.addEventListener("click", () => closePanel());
    });

    // Close when resizing up to desktop
    window.addEventListener("resize", () => {
      if (window.innerWidth > 860) closePanel();
    });
  }

  // --- Dark mode toggle ---
  const themeKey = "academic-hub-theme";
  const themeBtn = document.querySelector("[data-dark-toggle]");
  const prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;

  const setTheme = (mode) => {
    document.body.classList.toggle("dark", mode === "dark");
    localStorage.setItem(themeKey, mode);
    if (themeBtn) themeBtn.textContent = mode === "dark" ? "Light mode" : "Dark mode";
  };

  const saved = localStorage.getItem(themeKey);
  if (saved) setTheme(saved);
  else if (prefersDark) setTheme("dark");
  else setTheme("light");

  if (themeBtn) {
    themeBtn.addEventListener("click", () => {
      const isDark = document.body.classList.contains("dark");
      setTheme(isDark ? "light" : "dark");
    });
  }

  // --- Back to top button ---
  const backToTop = document.querySelector(".back-to-top");
  if (backToTop) {
    window.addEventListener("scroll", () => {
      backToTop.classList.toggle("show", window.scrollY > 400);
    });
    backToTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
  }

  // --- Fade-in animations ---
  const fadeEls = document.querySelectorAll(".fade-in");
  if (fadeEls.length) {
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );
    fadeEls.forEach((el) => observer.observe(el));
  }

  // --- Contact form -> WhatsApp ---
  const contactForm = document.querySelector("#contact-form");
  if (contactForm) {
    contactForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const name = (document.querySelector("#name")?.value || "").trim();
      const contact = (document.querySelector("#contact")?.value || "").trim();
      const subject = (document.querySelector("#subject")?.value || "").trim();
      const lessonType = (document.querySelector("#lesson-type")?.value || "").trim();
      const location = (document.querySelector("#location")?.value || "").trim();
      const message = (document.querySelector("#message")?.value || "").trim();
      const status = contactForm.querySelector(".form-status");

      const errors = [];
      if (!name) errors.push("Please enter your name.");
      if (!contact) errors.push("Please enter an email or phone number.");
      if (!subject) errors.push("Please enter a subject.");
      if (!lessonType) errors.push("Please select a lesson type.");
      if (!location) errors.push("Please enter your city/location.");
      if (!message) errors.push("Please add a message.");

      if (errors.length) {
        if (status) {
          status.textContent = errors.join(" ");
          status.style.color = "var(--danger)";
        }
        return;
      }

      const whatsappNumber = "263777414157";
      const text =
        "New lesson enquiry from website:%0A%0A" +
        `Name: ${encodeURIComponent(name)}%0A` +
        `Contact: ${encodeURIComponent(contact)}%0A` +
        `Subject: ${encodeURIComponent(subject)}%0A` +
        `Lesson type: ${encodeURIComponent(lessonType)}%0A` +
        `City/Location: ${encodeURIComponent(location)}%0A%0A` +
        `Message:%0A${encodeURIComponent(message)}`;

      const url = `https://wa.me/${whatsappNumber}?text=${text}`;
      window.open(url, "_blank");

      if (status) {
        status.textContent = "Opening WhatsApp…";
        status.style.color = "var(--success)";
      }
      contactForm.reset();
    });
  }
});
